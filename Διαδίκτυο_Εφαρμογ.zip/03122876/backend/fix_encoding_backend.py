from pathlib import Path


files_to_fix = [
    "main.py",
    "database.py",
    "create_db.py",
    "recommender.py",
]


def read_file_safely(path):
    for encoding in ["utf-8", "cp1253"]:
        try:
            return path.read_text(encoding=encoding)
        except UnicodeDecodeError:
            pass

    raise UnicodeDecodeError(
        "unknown",
        b"",
        0,
        1,
        f"Could not decode file: {path}"
    )


for file_name in files_to_fix:
    path = Path(file_name)

    if not path.exists():
        continue

    text = read_file_safely(path)
    path.write_text(text, encoding="utf-8")

    print(f"Fixed encoding: {file_name}")