# -*- coding: utf-8 -*-

"""
database.py

Αυτό το αρχείο είναι υπεύθυνο για την επικοινωνία με τη SQLite βάση.

Ρόλος:
- Ανοίγει σύνδεση με το movielens.db.
- Εκτελεί SQL queries.
- Επιστρέφει δεδομένα στο main.py.
- Περιέχει συναρτήσεις για αναζήτηση ταινιών, ratings και προσθήκη ταινίας.

Αναλογία:
Είναι ο υπεύθυνος αρχείων.
Το main.py του λέει τι χρειάζεται, και αυτός ψάχνει στη βάση
και επιστρέφει το αποτέλεσμα.
"""

import sqlite3
from pathlib import Path


BACKEND_DIR = Path(__file__).resolve().parent

#makes the path to the base : "movielens.db"
DATABASE_PATH = BACKEND_DIR / "movielens.db"


def get_connection():
    """
    Ανοίγει σύνδεση με τη SQLite βάση movielens.db.

    Το row_factory = sqlite3.Row μας επιτρέπει να παίρνουμε τα αποτελέσματα
    σαν λεξικά, δηλαδή με ονόματα στηλών, π.χ. row["title"].
    """

    connection = sqlite3.connect(DATABASE_PATH)
    connection.row_factory = sqlite3.Row
    return connection


def rows_to_dicts(rows):
    """
    Μετατρέπει τις γραμμές που επιστρέφει η SQLite σε λίστα από dictionaries.

    Αυτό είναι χρήσιμο γιατί το FastAPI μπορεί εύκολα να επιστρέψει dictionaries
    ως JSON response.
    """
    #this one row["movieId"] = 2571 turns it to "movieId": 2571,


    return [dict(row) for row in rows]


def get_movies_by_search(search):
    """
    Ψάχνει ταινίες στον πίνακα movies με βάση λέξη-κλειδί στον τίτλο.

    Παράδειγμα:
    Αν ο χρήστης ψάξει "matrix", εκτελείται SQL query που βρίσκει
    όσες ταινίες έχουν τη λέξη matrix στον τίτλο τους.

    Το LIKE χρησιμοποιείται για αναζήτηση μέσα σε κείμενο.
    Το LOWER χρησιμοποιείται ώστε η αναζήτηση να μη διαχωρίζει κεφαλαία/πεζά.
    """

    connection = get_connection()

    try:
        cursor = connection.cursor()

        cursor.execute(
            """
            SELECT movieId, title, genres
            FROM movies
            WHERE LOWER(title) LIKE LOWER(?)
            ORDER BY title
            """,
            (f"%{search}%",),  #parameterized query this is outside of the SQL query
        )

        rows = cursor.fetchall()
        return rows_to_dicts(rows)

    finally:
        connection.close()


def get_ratings_by_movie_id(movie_id):
    """
    Επιστρέφει όλες τις βαθμολογίες για μία συγκεκριμένη ταινία.

    Το movie_id έρχεται από το main.py.
    Με SQL query ψάχνουμε στον πίνακα ratings όλες τις γραμμές
    που έχουν το συγκεκριμένο movieId.
    """

    connection = get_connection()

    try:
        cursor = connection.cursor()

        cursor.execute(
            """
            SELECT userId, movieId, rating, timestamp
            FROM ratings
            WHERE movieId = ?
            """,
            (movie_id,),
        )

        rows = cursor.fetchall()
        return rows_to_dicts(rows)

    finally:
        connection.close()


def get_average_rating_by_movie_id(movie_id):
    """
    Υπολογίζει τον μέσο όρο βαθμολογίας μιας ταινίας.

    Χρησιμοποιούμε τη SQL συνάρτηση AVG(rating), η οποία υπολογίζει
    τον μέσο όρο των ratings για το συγκεκριμένο movieId.
    """

    connection = get_connection()

    try:
        cursor = connection.cursor()

        cursor.execute(
            """
            SELECT AVG(rating) AS averageRating, COUNT(*) AS ratingCount
            FROM ratings
            WHERE movieId = ?
            """,
            (movie_id,),
        )

        row = cursor.fetchone()

        return {
            "movieId": movie_id,
            "averageRating": row["averageRating"],
            "ratingCount": row["ratingCount"],
        }

    finally:
        connection.close()


def add_movie(title, genres):
    """
    Προσθέτει νέα ταινία στον πίνακα movies.

    Για να δώσουμε μοναδικό movieId:
    1. Βρίσκουμε το μεγαλύτερο movieId που υπάρχει ήδη.
    2. Δημιουργούμε νέο movieId = max_movie_id + 1.
    3. Κάνουμε INSERT τη νέα ταινία.
    """

    connection = get_connection()

    try:
        cursor = connection.cursor()

        cursor.execute("SELECT MAX(movieId) AS maxMovieId FROM movies")
        row = cursor.fetchone()

        max_movie_id = row["maxMovieId"]
        new_movie_id = max_movie_id + 1

        cursor.execute(
            """
            INSERT INTO movies (movieId, title, genres)
            VALUES (?, ?, ?)
            """,
            (new_movie_id, title, genres),
        )

        connection.commit()

        return new_movie_id

    finally:
        connection.close()


def get_movie_by_id(movie_id):
    """
    Επιστρέφει τα στοιχεία μιας ταινίας με βάση το movieId.

    Αυτή η συνάρτηση θα είναι χρήσιμη αργότερα στον recommender,
    ώστε όταν βρούμε προτεινόμενα movieIds να πάρουμε και τον τίτλο/genres.
    """

    connection = get_connection()

    try:
        cursor = connection.cursor()

        cursor.execute(
            """
            SELECT movieId, title, genres
            FROM movies
            WHERE movieId = ?
            """,
            (movie_id,),
        )

        row = cursor.fetchone()

        if row is None:
            return None

        return dict(row)

    finally:
        connection.close()


def get_all_ratings():
    """
    Επιστρέφει όλα τα ratings από τη βάση.

    Αυτή η συνάρτηση θα χρειαστεί αργότερα για τον recommendation αλγόριθμο,
    γιατί πρέπει να συγκρίνουμε τα ratings του web user με τα ratings
    των χρηστών του MovieLens dataset.
    """

    connection = get_connection()

    try:
        cursor = connection.cursor()

        cursor.execute(
            """
            SELECT userId, movieId, rating
            FROM ratings
            """
        )

        rows = cursor.fetchall()
        return rows_to_dicts(rows)

    finally:
        connection.close()