# -*- coding: utf-8 -*-

"""
create_db.py

Αυτό το αρχείο χρησιμοποιείται για να δημιουργήσει τη SQLite βάση δεδομένων
της εργασίας από τα CSV αρχεία του MovieLens dataset.

Ρόλος:
- Διαβάζει τα movies.csv, ratings.csv και tags.csv.
- Δημιουργεί τη βάση movielens.db.
- Φτιάχνει τους πίνακες movies, ratings και tags.
- Περνάει τα δεδομένα των CSV στους αντίστοιχους πίνακες.

Αναλογία:
Είναι ο οργανωτής της αρχικής αποθήκης.
Παίρνει τα αρχικά CSV αρχεία και τα βάζει οργανωμένα μέσα στη βάση.
"""

import csv
import sqlite3
from pathlib import Path


# Ο φάκελος backend, δηλαδή εκεί που βρίσκεται αυτό το αρχείο.
BACKEND_DIR = Path(__file__).resolve().parent

# Ο κεντρικός φάκελος MovieLens_Project.
PROJECT_DIR = BACKEND_DIR.parent

# Ο φάκελος που περιέχει τα CSV αρχεία του MovieLens.
DATASET_DIR = PROJECT_DIR / "ml-latest-small"

# Το αρχείο της SQLite βάσης που θα δημιουργηθεί.
DATABASE_PATH = BACKEND_DIR / "movielens.db"


def check_dataset_files():
    """
    Ελέγχει ότι υπάρχουν τα απαραίτητα CSV αρχεία.

    Αν λείπει κάποιο αρχείο, σταματάμε το πρόγραμμα με καθαρό μήνυμα λάθους.
    Αυτό μας προστατεύει από το να προσπαθήσουμε να φτιάξουμε βάση χωρίς δεδομένα.
    """

    required_files = [
        DATASET_DIR / "movies.csv",
        DATASET_DIR / "ratings.csv",
        DATASET_DIR / "tags.csv",
    ]

    for file_path in required_files:
        if not file_path.exists():
            raise FileNotFoundError(f"Δεν βρέθηκε το αρχείο: {file_path}")


def create_tables(connection):
    """
    Δημιουργεί τους πίνακες movies, ratings και tags στη SQLite βάση.

    Πρώτα διαγράφουμε τους πίνακες αν υπάρχουν ήδη, ώστε κάθε φορά που τρέχουμε
    το script να δημιουργείται καθαρή βάση από την αρχή.
    """

    cursor = connection.cursor()

    cursor.execute("DROP TABLE IF EXISTS movies")
    cursor.execute("DROP TABLE IF EXISTS ratings")
    cursor.execute("DROP TABLE IF EXISTS tags")

    cursor.execute(
        """
        CREATE TABLE movies (
            movieId INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            genres TEXT NOT NULL
        )
        """
    )

    cursor.execute(
        """
        CREATE TABLE ratings (
            userId INTEGER NOT NULL,
            movieId INTEGER NOT NULL,
            rating REAL NOT NULL,
            timestamp INTEGER NOT NULL
        )
        """
    )

    cursor.execute(
        """
        CREATE TABLE tags (
            userId INTEGER NOT NULL,
            movieId INTEGER NOT NULL,
            tag TEXT NOT NULL,
            timestamp INTEGER NOT NULL
        )
        """
    )

    connection.commit()


def load_movies(connection):
    """
    Διαβάζει το movies.csv και περνάει τις ταινίες στον πίνακα movies.

    Κάθε γραμμή του movies.csv έχει:
    - movieId
    - title
    - genres
    """

    movies_csv = DATASET_DIR / "movies.csv"
    cursor = connection.cursor()

    with open(movies_csv, mode="r", encoding="utf-8") as file:
        reader = csv.DictReader(file)

        for row in reader:
            cursor.execute(
                """
                INSERT INTO movies (movieId, title, genres)
                VALUES (?, ?, ?)
                """,
                (
                    int(row["movieId"]), #διότι έτσι είναι στην βάση ορισμένο , σαν Integer 
                    row["title"],
                    row["genres"],
                ),
            )

    connection.commit()


def load_ratings(connection):
    """
    Διαβάζει το ratings.csv και περνάει τις βαθμολογίες στον πίνακα ratings.

    Κάθε γραμμή του ratings.csv έχει:
    - userId
    - movieId
    - rating
    - timestamp
    """

    ratings_csv = DATASET_DIR / "ratings.csv"
    cursor = connection.cursor()

    with open(ratings_csv, mode="r", encoding="utf-8") as file:
        reader = csv.DictReader(file)

        for row in reader:
            cursor.execute(
                """
                INSERT INTO ratings (userId, movieId, rating, timestamp)
                VALUES (?, ?, ?, ?)
                """,
                (
                    int(row["userId"]),
                    int(row["movieId"]),
                    float(row["rating"]),
                    int(row["timestamp"]),
                ),
            )

    connection.commit()


def load_tags(connection):
    """
    Διαβάζει το tags.csv και περνάει τα tags στον πίνακα tags.

    Κάθε γραμμή του tags.csv έχει:
    - userId
    - movieId
    - tag
    - timestamp
    """

    tags_csv = DATASET_DIR / "tags.csv"
    cursor = connection.cursor()

    with open(tags_csv, mode="r", encoding="utf-8") as file:
        reader = csv.DictReader(file)

        for row in reader:
            cursor.execute(
                """
                INSERT INTO tags (userId, movieId, tag, timestamp)
                VALUES (?, ?, ?, ?)
                """,
                (
                    int(row["userId"]),
                    int(row["movieId"]),
                    row["tag"],
                    int(row["timestamp"]),
                ),
            )

    connection.commit()


def create_database():
    """
    Κεντρική συνάρτηση του αρχείου.

    Κάνει όλη τη διαδικασία:
    1. Ελέγχει ότι υπάρχουν τα CSV.
    2. Συνδέεται στη SQLite βάση.
    3. Δημιουργεί τους πίνακες.
    4. Φορτώνει τα δεδομένα.
    5. Κλείνει τη σύνδεση με τη βάση.
    """

    print("Έλεγχος αρχείων dataset...")
    check_dataset_files()

    print("Σύνδεση με SQLite βάση...")
    connection = sqlite3.connect(DATABASE_PATH)

    try:
        print("Δημιουργία πινάκων...")
        create_tables(connection)

        print("Φόρτωση movies.csv...")
        load_movies(connection)

        print("Φόρτωση ratings.csv...")
        load_ratings(connection)

        print("Φόρτωση tags.csv...")
        load_tags(connection)

        print("Η βάση δημιουργήθηκε επιτυχώς!")
        print(f"Αρχείο βάσης: {DATABASE_PATH}")

    finally:
        connection.close()


if __name__ == "__main__":
    create_database()