cd MovieLens_Project/backend
python3 -m pip install -r requirements.txt
python3 create_db.py

These are the steps we perform so far in order to download the required libraries and create the database.

In the backend, we can run the following command:

python3 -m uvicorn main:app --reload --port 3000

and we manually open http://127.0.0.1:3000/docs to find the backend API.

The actual application opens from the frontend, while we are in index.html and press Go Live.

Uvicorn runs only from the backend folder.
The frontend does not run with uvicorn.

Endpoints table:

GET  /movielens/api/movies?search={keyword}
POST /movielens/api/movies
GET  /movielens/api/ratings/{movieId}
POST /movielens/api/recommenda

Limitations / Notes:

* The ratings of the web user are stored only temporarily in the frontend, in the userRatings object.
* If the page is refreshed, the temporary ratings are lost.
* New movies are stored in the SQLite database.
* If create_db.py is run again, the database is reset from the CSV files.
* The application does not check duplicates for new movies. If the same title and genres are given, a new movieId is created.
* New movies do not directly affect the recommendations, because they do not have ratings from users of the MovieLens dataset.

Frontend flow:

index.html
contains the structure of the page

index.css
defines the appearance

index.js
reads inputs, handles buttons, makes fetch requests and dynamically updates the tables

Backend flow:

main.py
receives HTTP requests

database.py
communicates with the SQLite database

recommender.py
computes recommendations

create_db.py
creates and populates the database from the CSV files
