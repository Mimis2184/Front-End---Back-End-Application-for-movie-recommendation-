# -*- coding: utf-8 -*-

"""
main.py

Αυτό είναι το βασικό αρχείο του backend.

Ρόλος:
- Δημιουργεί το FastAPI app.
- Ενεργοποιεί CORS ώστε να μπορεί το frontend να καλεί το backend.
- Ορίζει τα API endpoints.
- Δέχεται requests από το frontend.
- Καλεί το database.py όταν χρειάζεται δεδομένα από τη βάση.
- Καλεί το recommender.py όταν χρειάζεται recommendations.
- Επιστρέφει απαντήσεις σε JSON μορφή.
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from database import (
    get_movies_by_search,
    get_ratings_by_movie_id,
    get_average_rating_by_movie_id,
    add_movie,
)

from recommender import get_recommendations


app = FastAPI(title="MovieLens API")


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Base path σύμφωνα με την εκφώνηση:
# http://localhost:3000/movielens/api
API_PREFIX = "/movielens/api"


class MovieCreateRequest(BaseModel):
    """
    Μοντέλο για το request body όταν ο χρήστης προσθέτει νέα ταινία.

    Το frontend θα στέλνει JSON σαν:
    {
        "title": "Movie Title",
        "genres": "Action|Drama"
    }
    """

    title: str
    genres: str


class RatingInput(BaseModel):
    """
    Μοντέλο για μία βαθμολογία που δίνει ο web user.

    Παράδειγμα:
    {
        "movieId": 1,
        "rating": 4.5
    }
    """

    movieId: int
    rating: float


class RecommendationRequest(BaseModel):
    """
    Μοντέλο για το request body του recommendations endpoint.

    Το frontend θα στέλνει JSON σαν:
    {
        "ratings": [
            {"movieId": 1, "rating": 4.5},
            {"movieId": 2571, "rating": 5.0}
        ]
    }
    """

    ratings: list[RatingInput]


@app.get(f"{API_PREFIX}/movies")
def search_movies(search: str):
    """
    GET /movielens/api/movies?search={keyword}

    Ρόλος:
    - Παίρνει από το frontend τη λέξη αναζήτησης.
    - Καλεί το database.py για να ψάξει στον πίνακα movies.
    - Επιστρέφει τις ταινίες σε JSON μορφή.
    """

    movies = get_movies_by_search(search)

    return {
        "status": "success",
        "movies": movies,
    }


@app.get(f"{API_PREFIX}/ratings/{{movie_id}}")
def get_movie_ratings(movie_id: int):
    """
    GET /movielens/api/ratings/{movieId}

    Ρόλος:
    - Παίρνει το movieId από το URL.
    - Καλεί το database.py για να φέρει όλα τα ratings αυτής της ταινίας.
    - Υπολογίζει επίσης τον μέσο όρο βαθμολογίας.
    - Επιστρέφει JSON απάντηση στο frontend.
    """

    ratings = get_ratings_by_movie_id(movie_id)
    average_info = get_average_rating_by_movie_id(movie_id)

    return {
        "status": "success",
        "ratings": ratings,
        "averageRating": average_info["averageRating"],
        "ratingCount": average_info["ratingCount"],
    }


@app.post(f"{API_PREFIX}/movies")
def create_movie(movie: MovieCreateRequest):
    """
    POST /movielens/api/movies

    Ρόλος:
    - Παίρνει JSON body από το frontend με title και genres.
    - Ελέγχει ότι τα πεδία δεν είναι κενά.
    - Καλεί το database.py για να προσθέσει τη νέα ταινία.
    - Επιστρέφει το νέο movieId.
    """

    title = movie.title.strip()
    genres = movie.genres.strip()

    if not title:
        raise HTTPException(
            status_code=400,
            detail="Το title δεν μπορεί να είναι κενό.",
        )

    if not genres:
        raise HTTPException(
            status_code=400,
            detail="Το genres δεν μπορεί να είναι κενό.",
        )

    new_movie_id = add_movie(title, genres)

    return {
        "status": "success",
        "movieId": new_movie_id,
    }


@app.post(f"{API_PREFIX}/recommendations")
def recommend_movies(request: RecommendationRequest):
    """
    POST /movielens/api/recommendations

    Ρόλος:
    - Παίρνει από το frontend τα προσωρινά ratings του web user.
    - Δεν τα αποθηκεύει στη βάση.
    - Καλεί το recommender.py.
    - Επιστρέφει προτεινόμενες ταινίες σε JSON μορφή.
    """

    if not request.ratings:
        raise HTTPException(
            status_code=400,
            detail="Πρέπει να δοθεί τουλάχιστον μία βαθμολογία.",
        )

    user_ratings = []

    for item in request.ratings:
        if item.rating < 0.5 or item.rating > 5.0:
            raise HTTPException(
                status_code=400,
                detail="Οι βαθμολογίες πρέπει να είναι από 0.5 έως 5.0.",
            )

        user_ratings.append(
            {
                "movieId": item.movieId,
                "rating": item.rating,
            }
        )

    recommendations = get_recommendations(user_ratings)

    return {
        "status": "success",
        "recommendations": recommendations,
    }


@app.get(f"{API_PREFIX}/health")
def health_check():
    """
    GET /movielens/api/health

    Ρόλος:
    - Ελέγχει αν το backend τρέχει.
    """

    return {
        "status": "success",
        "message": "MovieLens API is running",
    }