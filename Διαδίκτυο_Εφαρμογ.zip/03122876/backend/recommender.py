# -*- coding: utf-8 -*-

"""
recommender.py

Αυτό το αρχείο περιέχει τον αλγόριθμο προτάσεων ταινιών.

Ρόλος:
- Παίρνει τα προσωρινά ratings που έδωσε ο web user.
- Συγκρίνει τον web user με τους χρήστες του MovieLens dataset.
- Υπολογίζει Pearson similarity.
- Επιλέγει τους top-K πιο παρόμοιους χρήστες.
- Προβλέπει ratings για ταινίες που δεν έχει βαθμολογήσει ο web user.
- Επιστρέφει τις top-N προτεινόμενες ταινίες.

Αναλογία:
Είναι ο ειδικός προτάσεων.
Παίρνει τις προτιμήσεις του χρήστη και βρίσκει ποιες ταινίες
είναι πιθανό να του αρέσουν.
"""

from collections import defaultdict
from math import sqrt

from database import get_all_ratings, get_movie_by_id


def build_ratings_by_user(all_ratings):
    """
    Οργανώνει όλα τα ratings της βάσης ανά χρήστη.

    Η βάση μας επιστρέφει ratings σε μορφή λίστας:
    [
        {"userId": 1, "movieId": 1, "rating": 4.0},
        {"userId": 1, "movieId": 3, "rating": 5.0},
        {"userId": 2, "movieId": 1, "rating": 3.5}
    ]

    Εμείς τα μετατρέπουμε σε μορφή:
    {
        1: {1: 4.0, 3: 5.0},
        2: {1: 3.5}
    }

    Δηλαδή:
    userId -> movieId -> rating
    """

    ratings_by_user = defaultdict(dict)

    for row in all_ratings:
        user_id = row["userId"]
        movie_id = row["movieId"]
        rating = row["rating"]

        ratings_by_user[user_id][movie_id] = rating

    return ratings_by_user


def calculate_mean_rating(ratings_dict):
    """
    Υπολογίζει τον μέσο όρο βαθμολογιών ενός χρήστη.

    Παράδειγμα:
    Αν ένας χρήστης έχει ratings:
    {1: 4.0, 3: 5.0, 10: 3.0}

    τότε ο μέσος όρος είναι:
    (4.0 + 5.0 + 3.0) / 3
    """

    if not ratings_dict:
        return 0

    return sum(ratings_dict.values()) / len(ratings_dict)


def pearson_similarity(web_user_ratings, other_user_ratings):
    """
    Υπολογίζει Pearson correlation ανάμεσα στον web user
    και έναν χρήστη του MovieLens dataset.

    Χρησιμοποιούμε μόνο τις κοινές ταινίες που έχουν βαθμολογήσει και οι δύο.

    Αν το αποτέλεσμα είναι:
    - κοντά στο 1: οι χρήστες μοιάζουν πολύ
    - κοντά στο 0: δεν υπάρχει ισχυρή σχέση
    - κοντά στο -1: έχουν αντίθετες προτιμήσεις

    Εμείς κρατάμε μόνο θετικές ομοιότητες.
    """

    # Βρίσκουμε τις κοινές ταινίες που έχουν βαθμολογήσει και οι δύο χρήστες.
    common_movies = set(web_user_ratings.keys()) & set(other_user_ratings.keys())

    # Αν έχουν λιγότερες από 2 κοινές ταινίες, δεν βγάζουμε αξιόπιστο Pearson.
    if len(common_movies) < 2:
        return 0

    # Παίρνουμε τις βαθμολογίες του web user στις κοινές ταινίες.
    web_user_values = [web_user_ratings[movie_id] for movie_id in common_movies]

    # Παίρνουμε τις βαθμολογίες του άλλου χρήστη στις ίδιες κοινές ταινίες.
    other_user_values = [other_user_ratings[movie_id] for movie_id in common_movies]

    # Υπολογίζουμε μέσο όρο βαθμολογίας για κάθε χρήστη, μόνο στις κοινές ταινίες.
    web_user_mean = sum(web_user_values) / len(web_user_values)
    other_user_mean = sum(other_user_values) / len(other_user_values)

    numerator = 0
    web_user_denominator_part = 0
    other_user_denominator_part = 0

    for movie_id in common_movies:
        # Απόκλιση βαθμολογίας web user από τον μέσο όρο του.
        web_user_diff = web_user_ratings[movie_id] - web_user_mean

        # Απόκλιση βαθμολογίας άλλου χρήστη από τον μέσο όρο του.
        other_user_diff = other_user_ratings[movie_id] - other_user_mean

        # Αριθμητής Pearson.
        numerator += web_user_diff * other_user_diff

        # Μέρη του παρονομαστή Pearson.
        web_user_denominator_part += web_user_diff ** 2
        other_user_denominator_part += other_user_diff ** 2

    denominator = sqrt(web_user_denominator_part) * sqrt(other_user_denominator_part)

    # Αν ο παρονομαστής είναι 0, δεν μπορούμε να διαιρέσουμε.
    if denominator == 0:
        return 0

    return numerator / denominator


def get_top_similar_users(web_user_ratings, ratings_by_user, k=20):
    """
    Βρίσκει τους top-K πιο παρόμοιους χρήστες με τον web user.

    Για κάθε χρήστη του MovieLens:
    - υπολογίζουμε Pearson similarity
    - κρατάμε μόνο θετικές ομοιότητες
    - ταξινομούμε από τη μεγαλύτερη προς τη μικρότερη
    - επιστρέφουμε τους πρώτους K
    """
    
    similarities = []

    for user_id, other_user_ratings in ratings_by_user.items():
        similarity = pearson_similarity(web_user_ratings, other_user_ratings)

        # Κρατάμε μόνο χρήστες με θετική ομοιότητα.
        if similarity > 0:
            similarities.append((user_id, similarity))

    # Ταξινόμηση με βάση το similarity, από το μεγαλύτερο στο μικρότερο.
    similarities.sort(key=lambda item: item[1], reverse=True)

    return similarities[:k]


def predict_ratings(web_user_ratings, ratings_by_user, similar_users):
    """
    Προβλέπει βαθμολογίες για ταινίες που δεν έχει βαθμολογήσει ο web user.

    Η λογική είναι:
    Αν παρόμοιοι χρήστες έχουν βαθμολογήσει καλά μια ταινία,
    τότε είναι πιθανό να αρέσει και στον web user.

    Δεν προτείνουμε ταινίες που ο web user έχει ήδη βαθμολογήσει.
    """

    # Μέσος όρος βαθμολογιών του web user.
    web_user_mean = calculate_mean_rating(web_user_ratings)

    # Υπολογίζουμε μέσο όρο βαθμολογίας για κάθε χρήστη του dataset.
    user_means = {}

    for user_id, ratings in ratings_by_user.items():
        user_means[user_id] = calculate_mean_rating(ratings)

    # Εδώ θα μαζεύουμε αριθμητή και παρονομαστή για κάθε candidate movie.
    predictions = {}

    for user_id, similarity in similar_users:
        other_user_ratings = ratings_by_user[user_id]
        other_user_mean = user_means[user_id]

        for movie_id, rating in other_user_ratings.items():

            # Αν ο web user έχει ήδη βαθμολογήσει αυτή την ταινία, δεν την προτείνουμε.
            if movie_id in web_user_ratings:
                continue

            if movie_id not in predictions:
                predictions[movie_id] = {
                    "numerator": 0,
                    "denominator": 0,
                }

            # Σταθμισμένη συνεισφορά του παρόμοιου χρήστη.
            predictions[movie_id]["numerator"] += similarity * (rating - other_user_mean)

            # Άθροισμα απόλυτων similarity για τον παρονομαστή.
            predictions[movie_id]["denominator"] += abs(similarity)

    predicted_ratings = []

    for movie_id, values in predictions.items():
        denominator = values["denominator"]

        if denominator == 0:
            continue

        predicted_rating = web_user_mean + (values["numerator"] / denominator)

        # Τα MovieLens ratings είναι συνήθως από 0.5 έως 5.0.
        # Περιορίζουμε την πρόβλεψη σε αυτό το εύρος.
        if predicted_rating < 0.5:
            predicted_rating = 0.5

        if predicted_rating > 5.0:
            predicted_rating = 5.0

        predicted_ratings.append((movie_id, predicted_rating))

    # Ταξινομούμε από την καλύτερη πρόβλεψη προς τη χειρότερη.
    predicted_ratings.sort(key=lambda item: item[1], reverse=True)

    return predicted_ratings


def get_recommendations(user_ratings_list, k=20, n=10):
    """
    Κεντρική συνάρτηση του recommender.

    Input από το frontend:
    [
        {"movieId": 1, "rating": 4.5},
        {"movieId": 2571, "rating": 5.0}
    ]

    Output προς το main.py:
    [
        {
            "movieId": 296,
            "title": "...",
            "genres": "...",
            "predictedRating": 4.72
        }
    ]

    Παράμετροι:
    - k: πόσους παρόμοιους χρήστες κρατάμε
    - n: πόσες προτεινόμενες ταινίες επιστρέφουμε
    """

    web_user_ratings = {}

    # Μετατρέπουμε τη λίστα ratings του frontend σε dictionary:
    # movieId -> rating
    for item in user_ratings_list:
        movie_id = item["movieId"]
        rating = item["rating"]

        web_user_ratings[movie_id] = rating

    # Παίρνουμε όλα τα ratings από τη βάση.
    all_ratings = get_all_ratings()

    # Οργανώνουμε τα ratings ανά χρήστη.
    ratings_by_user = build_ratings_by_user(all_ratings)

    # Βρίσκουμε τους top-K πιο παρόμοιους χρήστες.
    similar_users = get_top_similar_users(
        web_user_ratings,
        ratings_by_user,
        k=k,
    )

    # Προβλέπουμε ratings για ταινίες που δεν έχει βαθμολογήσει ο web user.
    predicted_ratings = predict_ratings(
        web_user_ratings,
        ratings_by_user,
        similar_users,
    )

    recommendations = []

    # Παίρνουμε τις πρώτες N καλύτερες προβλέψεις.
    for movie_id, predicted_rating in predicted_ratings[:n]:
        movie = get_movie_by_id(movie_id)

        if movie is None:
            continue

        recommendations.append(
            {
                "movieId": movie["movieId"],
                "title": movie["title"],
                "genres": movie["genres"],
                "predictedRating": round(predicted_rating, 2),
            }
        )

    return recommendations