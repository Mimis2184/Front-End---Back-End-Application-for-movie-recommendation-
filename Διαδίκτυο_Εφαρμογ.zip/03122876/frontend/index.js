/*
index.js

This file contains the frontend logic.

Role:
- Reads user input from the page.
- Handles button clicks.
- Sends requests to the FastAPI backend using fetch().
- Sends and receives JSON.
- Displays search results, user ratings, and recommendations.
- Stores user ratings temporarily in the browser memory.
*/

const API_BASE_URL = "http://127.0.0.1:3000/movielens/api";

const messageArea = document.getElementById("messageArea");

const newMovieTitleInput = document.getElementById("newMovieTitle");
const newMovieGenresInput = document.getElementById("newMovieGenres");
const addMovieButton = document.getElementById("addMovieButton");

const searchInput = document.getElementById("searchInput");
const searchButton = document.getElementById("searchButton");

const moviesTableBody = document.getElementById("moviesTableBody");
const userRatingsTableBody = document.getElementById("userRatingsTableBody");
const recommendationsTableBody = document.getElementById("recommendationsTableBody");

const recommendationsButton = document.getElementById("recommendationsButton");

/*
This object stores the ratings of the current web user temporarily.

Example:
{
    1: { movieId: 1, title: "Toy Story (1995)", rating: 4.5 },
    2571: { movieId: 2571, title: "Matrix, The (1999)", rating: 5.0 }
}

These ratings are not saved in the SQLite database.
*/
const userRatings = {};


function showMessage(message, type = "info") {
    messageArea.innerHTML = "";

    const messageDiv = document.createElement("div");
    messageDiv.className = `message ${type}`;
    messageDiv.textContent = message;

    messageArea.appendChild(messageDiv);
}


function clearMessage() {
    messageArea.innerHTML = "";
}


function clearTable(tableBody) {
    tableBody.innerHTML = "";
}


function showEmptyRow(tableBody, colspan, text) {
    clearTable(tableBody);

    const row = document.createElement("tr");
    const cell = document.createElement("td");

    cell.colSpan = colspan;
    cell.textContent = text;
    cell.className = "empty-row";

    row.appendChild(cell);
    tableBody.appendChild(row);
}


async function addMovie() {
    clearMessage();

    const title = newMovieTitleInput.value.trim();
    const genres = newMovieGenresInput.value.trim();

    if (!title || !genres) {
        showMessage("Please fill in both movie title and genres.", "error");
        return;
    }

    try {
        const response = await fetch(`${API_BASE_URL}/movies`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                title: title,
                genres: genres
            })
        });

        const data = await response.json();

        if (!response.ok) {
            showMessage(data.detail || "Failed to add movie.", "error");
            return;
        }

        showMessage(`Movie added successfully with ID ${data.movieId}.`, "success");

        newMovieTitleInput.value = "";
        newMovieGenresInput.value = "";

    } catch (error) {
        showMessage("Could not connect to the backend server.", "error");
    }
}


async function getAverageRating(movieId) {
    try {
        const response = await fetch(`${API_BASE_URL}/ratings/${movieId}`);
        const data = await response.json();

        if (!response.ok) {
            return "N/A";
        }

        if (data.averageRating === null) {
            return "No ratings";
        }

        return `${data.averageRating.toFixed(2)} (${data.ratingCount})`;

    } catch (error) {
        return "N/A";
    }
}


async function searchMovies() {
    clearMessage();
    clearTable(moviesTableBody);
    clearTable(recommendationsTableBody);

    const search = searchInput.value.trim();

    if (!search) {
        showMessage("Please type a movie title to search.", "error");
        return;
    }

    try {
        const response = await fetch(`${API_BASE_URL}/movies?search=${encodeURIComponent(search)}`);
        const data = await response.json();

        if (!response.ok) {
            showMessage(data.detail || "Search failed.", "error");
            return;
        }

        if (data.movies.length === 0) {
            showEmptyRow(moviesTableBody, 5, "No movies found.");
            return;
        }

        for (const movie of data.movies) {
            const averageRating = await getAverageRating(movie.movieId);
            addMovieResultRow(movie, averageRating);
        }

        showMessage(`Found ${data.movies.length} movie(s).`, "success");

    } catch (error) {
        showMessage("Could not connect to the backend server.", "error");
    }
}


function addMovieResultRow(movie, averageRating) {
    const row = document.createElement("tr");

    const movieIdCell = document.createElement("td");
    movieIdCell.textContent = movie.movieId;

    const titleCell = document.createElement("td");
    titleCell.textContent = movie.title;

    const genresCell = document.createElement("td");
    genresCell.textContent = movie.genres;

    const averageRatingCell = document.createElement("td");
    averageRatingCell.textContent = averageRating;

    const ratingCell = document.createElement("td");

    const ratingInput = document.createElement("input");
    ratingInput.type = "number";
    ratingInput.min = "0.5";
    ratingInput.max = "5";
    ratingInput.step = "0.5";
    ratingInput.placeholder = "0.5 - 5";
    ratingInput.className = "rating-input";

    if (userRatings[movie.movieId]) {
        ratingInput.value = userRatings[movie.movieId].rating;
    }

    const saveButton = document.createElement("button");
    saveButton.textContent = "Save Rating";

    saveButton.addEventListener("click", function () {
        saveUserRating(movie, ratingInput.value);
    });

    ratingCell.appendChild(ratingInput);
    ratingCell.appendChild(saveButton);

    row.appendChild(movieIdCell);
    row.appendChild(titleCell);
    row.appendChild(genresCell);
    row.appendChild(averageRatingCell);
    row.appendChild(ratingCell);

    moviesTableBody.appendChild(row);
}


function saveUserRating(movie, ratingValue) {
    const rating = Number(ratingValue);

    if (!ratingValue || Number.isNaN(rating)) {
        showMessage("Please enter a valid rating.", "error");
        return;
    }

    if (rating < 0.5 || rating > 5.0) {
        showMessage("Rating must be between 0.5 and 5.0.", "error");
        return;
    }

    userRatings[movie.movieId] = {
        movieId: movie.movieId,
        title: movie.title,
        rating: rating
    };

    renderUserRatingsTable();

    showMessage(`Saved rating ${rating} for "${movie.title}".`, "success");
}


function renderUserRatingsTable() {
    clearTable(userRatingsTableBody);

    const ratingsArray = Object.values(userRatings);

    if (ratingsArray.length === 0) {
        showEmptyRow(userRatingsTableBody, 4, "No ratings yet.");
        return;
    }

    for (const item of ratingsArray) {
        const row = document.createElement("tr");

        const movieIdCell = document.createElement("td");
        movieIdCell.textContent = item.movieId;

        const titleCell = document.createElement("td");
        titleCell.textContent = item.title;

        const ratingCell = document.createElement("td");
        ratingCell.textContent = item.rating;

        const actionCell = document.createElement("td");

        const removeButton = document.createElement("button");
        removeButton.textContent = "Remove";
        removeButton.className = "danger";

        removeButton.addEventListener("click", function () {
            delete userRatings[item.movieId];
            renderUserRatingsTable();
            showMessage(`Removed rating for "${item.title}".`, "info");
        });

        actionCell.appendChild(removeButton);

        row.appendChild(movieIdCell);
        row.appendChild(titleCell);
        row.appendChild(ratingCell);
        row.appendChild(actionCell);

        userRatingsTableBody.appendChild(row);
    }
}


async function getRecommendations() {
    clearMessage();
    clearTable(recommendationsTableBody);

    const ratingsArray = Object.values(userRatings);

    if (ratingsArray.length === 0) {
        showMessage("Please rate at least one movie before requesting recommendations.", "error");
        return;
    }

    const requestBody = {
        ratings: ratingsArray.map(function (item) {
            return {
                movieId: item.movieId,
                rating: item.rating
            };
        })
    };

    try {
        const response = await fetch(`${API_BASE_URL}/recommendations`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(requestBody)
        });

        const data = await response.json();

        if (!response.ok) {
            showMessage(data.detail || "Failed to get recommendations.", "error");
            return;
        }

        if (data.recommendations.length === 0) {
            showEmptyRow(recommendationsTableBody, 4, "No recommendations found.");
            return;
        }

        renderRecommendationsTable(data.recommendations);

        showMessage("Recommendations generated successfully.", "success");

    } catch (error) {
        showMessage("Could not connect to the backend server.", "error");
    }
}


function renderRecommendationsTable(recommendations) {
    clearTable(recommendationsTableBody);

    for (const movie of recommendations) {
        const row = document.createElement("tr");

        const movieIdCell = document.createElement("td");
        movieIdCell.textContent = movie.movieId;

        const titleCell = document.createElement("td");
        titleCell.textContent = movie.title;

        const genresCell = document.createElement("td");
        genresCell.textContent = movie.genres;

        const predictedRatingCell = document.createElement("td");
        predictedRatingCell.textContent = movie.predictedRating;

        row.appendChild(movieIdCell);
        row.appendChild(titleCell);
        row.appendChild(genresCell);
        row.appendChild(predictedRatingCell);

        recommendationsTableBody.appendChild(row);
    }
}


addMovieButton.addEventListener("click", addMovie);
searchButton.addEventListener("click", searchMovies);
recommendationsButton.addEventListener("click", getRecommendations);

searchInput.addEventListener("keydown", function (event) {
    if (event.key === "Enter") {
        searchMovies();
    }
});

renderUserRatingsTable();
showEmptyRow(moviesTableBody, 5, "Search for movies to display results.");
showEmptyRow(recommendationsTableBody, 4, "No recommendations yet.");